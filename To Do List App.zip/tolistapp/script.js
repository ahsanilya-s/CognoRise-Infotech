document.addEventListener('DOMContentLoaded', loadTasks);

function loadTasks() {
    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    tasks.forEach(task => addTaskToDOM(task));
}

function addTask() {
    const taskInput = document.getElementById('taskInput');
    const task = taskInput.value.trim();
    if (task === '') return;
    
    addTaskToDOM(task);
    saveTask(task);
    taskInput.value = '';
}

function addTaskToDOM(task) {
    const taskList = document.getElementById('taskList');
    const li = document.createElement('li');
    
    li.innerHTML = `
        <span>${task}</span>
        <div class="actions">
            <button class="edit" onclick="editTask(this)">Edit</button>
            <button class="delete" onclick="deleteTask(this)">Delete</button>
        </div>
    `;
    taskList.appendChild(li);
}

function saveTask(task) {
    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    tasks.push(task);
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

function editTask(button) {
    const li = button.parentElement.parentElement;
    const taskSpan = li.querySelector('span');
    const newTask = prompt('Edit task:', taskSpan.textContent);
    
    if (newTask && newTask.trim() !== '') {
        taskSpan.textContent = newTask.trim();
        updateTaskInStorage();
    }
}

function deleteTask(button) {
    const li = button.parentElement.parentElement;
    li.remove();
    updateTaskInStorage();
}

function updateTaskInStorage() {
    const tasks = [];
    document.querySelectorAll('#taskList li span').forEach(taskSpan => {
        tasks.push(taskSpan.textContent);
    });
    localStorage.setItem('tasks', JSON.stringify(tasks));
}
